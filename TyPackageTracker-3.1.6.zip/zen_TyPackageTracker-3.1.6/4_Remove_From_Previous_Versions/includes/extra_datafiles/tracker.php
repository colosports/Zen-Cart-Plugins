<?php
/*
 * This file is derived from account_history_info.php
 *
 ******************************************************************************
 * @package languageDefines
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: account_history_info.php 3027 2006-02-13 17:15:51Z drbyte $
 ******************************************************************************
 * File ID: ty_package_tracker.php v2.2 by colosports
 */
define('FILENAME_ACCOUNT_HISTORY_TRACK', 'tracker');
define('BOX_HEADING_TRACK_ORDERS', 'Previous Orders');
?>