Ty Package Tracker for Zen Cart v3.1.6
=======
Changelog
---------------
<p>Version 3.1.6 - 12/27/2018</p>
<ul>
<li>Updated for Zen Cart v1.5.6 (jeking)</li>
<li>Removed integration with Super Orders and Edit Orders. (jeking)</li>
</ul>