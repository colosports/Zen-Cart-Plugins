Ty UPS WorldShip 10 module.  The module was tested on  Zen Cart 1.3.8a and WorldShip 10.
The WorldShip module will send WorldShip the shipping and package information to create shipping labels.

=========================================
REVISION HISTORY
=========================================
9/10/08 - Beta complete.
9/16/08 - Ty_UPS_Worldship10_v1 initial released.
10/01/08 - Ty_UPS_Worldship10_v1.0b
10/02/08 - Ty_UPS_Worldship10_v1.0c - final beta version


=========================================
FILES ADDED
=========================================
admin/ups_xml.php
admin/ups_xml_a.php
admin/ups_xml_admin.php


=========================================
FILES MODIFIED = 1
=========================================
Make sure you make a backup of the file that you will be modifying.
See Installation section below.

=========================================
INSTALLATION
=========================================
Add the following code to your order detail page that you will be using to ship packages
(orders.php, tracker.php, or super_orders.php)
////////////////////////////////////////////////////////////////////////////

<?php // ====> BOF: Ty UPS WorldShip <==== ?>  			
			<td align="right">
				<form action="ups_xml.php" method="get">
					<table border="1" width="250px" cellspacing="2" cellpadding="2">
						<tr>						
							<td>
								L:<input name="length" size="1" value="">
								W:<input name="width" size="1" value="">
								H:<input name="height" size="1" value="">
							</td>
							<td>
								Weight:<input name="weight" size="1" value="">
			                </td>
			            </tr>
						<tr>
							<td colspan="2">
								<?php if (WORLDSHIP_RESIDENTIAL == 'Residential') 
								echo '<input type="radio" name="residential_check" checked="checked" value="1">Residential &nbsp;<input type="radio" name="residential_check" value="0">Commercial';
								else
								echo '<input type="radio" name="residential_check" value="1">Residential &nbsp;<input type="radio" name="residential_check" checked="checked" value="0">Commercial';
								?>	
								<input type="hidden" name="oID" value="<?php echo $oID;?>">								   <INPUT TYPE="SUBMIT" VALUE="Ship">		
							</td>		  
			            </tr>
					</table>				
				</form>
			</td>
			<td align="right">
				<form action="ups_xml_advance.php" method="get">
					Packages:<input name="nop" size="1" value="1">
					<br />
					<input type="hidden" name="oID" value="<?php echo $oID;?>">
					<INPUT type="submit" value="UPS Advance"></td>		 
			    </form>
			</td>				
<?php // ====> EOF: Ty UPS WorldShip <==== ?>  	

//////////////////////////////////////////////////////////////////////////////

For me, I use tracker.php and I added the above code right BEFORE the following:
It's somewhere around line 319.
//////////////////////////////////////////////////////////////////////////////
            <td align="right">			
				<table border="0"><tr><td>
					<?php
		              if (SUPER_ORDERS_MOD_STATUS == 'True') {
		                echo '<a href="' . zen_href_link(FILENAME_EDIT, 'action=edit&oID=' . $_GET['oID'], 'NONSSL') . '">' . zen_image_button('button_edit.gif', IMAGE_EDIT) . '</a>&nbsp;&nbsp;';
//////////////////////////////////////////////////////////////////////////////
						
						
=========================================			
INITIAL SETTINGS
=========================================
1. Open UPS Worldship program. Go to menu setting "Import/Export Data->XML Auto Import..."
2. Select the folder for XML Auto Import File Folder. Default is c:\UPS\WSTD\ImpExp\XML Auto Import\. Change this to the folder where your internet browser will store all downloaded files. For Firefox, go to Tools->Options to see where the the browser stores downloaded files.  Mine is set to C:\DOWNLOADS.  WARNING: Make sure there are no other .xml files in that folder.  WorldShip will try to process are XML file in that folder and delete it after it is done processing.  All xml files in that folder will be lost.
3. Click on the Close button.
4. Copy the files from the WorldShip module to your server.
5. Run WorldShip_Install.sql in Admin->Install SQL Patches.
6. Go to Admin->Configuration->Ty UPS WorldShip 10
7. (Optional) If you want to display the comments in the comment box in HTML so that you and the customer can click on the link to track the packages, you will have to modify 2 core files. admin/orders.php and Go to your order detail page (i.e. admin/orders.php), search for the following code:
nl2br(zen_db_output($orders_history->fields['comments']))
change it to:
nl2br($orders_history->fields['comments'])

Go to your customer order detail page (i.e. /public_html/includes/templates/YOUR_TEMPLATE/templates/tpl_account_history_info_default.php), search for the following code:
nl2br(zen_output_string_protected($statuses['comments'])));
change it to:
nl2br($statuses['comments'])); 
=========================================			
USAGE - quick ship (one package)
=========================================
1. Open UPS Worldship program. Go to menu setting "Import/Export Data->XML Auto Import..."
2. Click on the Start Button.
3. Go to the Zen Cart Admin Order Detail Page (i.e. tracker.php)
4. You will see a few options for Package Information: Length, Width, Height, and Weight of the Package.  You will also see a checkbox.  Check the box if shipped to Residential Address.  Uncheck the box if ship to Commercial address.  The only value required is the Weight.  Enter the weight in the box and Submit.  If you are prompted to save openShipment.xml file, click Save. If you are prompted with "Save As" set folder to the same folder as in Step 2 of INITIAL SETTNGS above.  UPS Worldship will automatically process the shipping address and the weight to create the label(s). 
5. If you get Failed Shipment, click on the View Log in the WorldShip program.
6. When you are done shipping all package for the day, Go to Worldship program and click on Stop button.  Click on Close button. Click on End of Day to close out.


=========================================			
USAGE - Advance ship (multiple packages to one address)
=========================================
1. Open UPS Worldship program. Go to menu setting "Import/Export Data->XML Auto Import..."
2. Click on the Start Button.
3. Go to the Zen Cart Admin Order Detail Page (i.e. tracker.php).
4. Click on the Advance button to go to the Detail Shipping page. On this page you can make corrections to the shipping address if needed (Changes on this page are not save to the database). If you have multiple packages to the same address, enter the number of packages you are going to ship in the box and update.  Again, the only value you have to enter is the weight of each packages.  Enter the weight in the box and Submit.  If you are prompted to save openShipment.xml file, click Save. If you are prompted with "Save As" set folder to the same folder as in Step 2 of INITIAL SETTNGS above.  UPS Worldship will automatically process the shipping address and the weight to create the label(s). 
5. If you get Failed Shipment, click on the View Log in the WorldShip program.
6. When you are done shipping all package for the day, Go to Worldship program and click on Stop button.  Click on Close button. Click on End of Day to close out.



=========================================			
NOTES
=========================================

1. If you get Failed Shipments.  View the "View Log" Button under "Import/Export Data->XML Auto Import..."
Most of the error are self explaintory.  
	Common errors:
	a) The Package Weight for package number 1 must be greater than 0.  
		You did not enter the weight of the package.
	b) The Service is not a supported UPS Service Type.  
		I get this when I try to ship USPS Priority Mail Package. Duhhh.
	c) openShippment.xml Error on line 0, XML document must have a top level element.
		Error in the xml file.  Send the message to the author.

2. If you get Failed Shipments, it will appear under the Shipment History section.  You can void it to delete it from the record.  Failed shipments will not be on your bill.

3. If you need to access other features of the WorldShip program, you must stop and close the XML Auto Import.  Start it back up again when you are ready to ship again.

4.  UPS Quantum View may send the customer an email address with the tracking number after you close out (End of Day).   It usually takes a few hours after your close out before your customers receive delivery emails.
