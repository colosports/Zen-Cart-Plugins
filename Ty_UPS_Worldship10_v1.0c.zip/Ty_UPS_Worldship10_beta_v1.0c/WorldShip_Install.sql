SET @tyid=7878;
SELECT (@tyid:=configuration_group_id) as tyid 
FROM configuration_group
WHERE configuration_group_title= 'Ty UPS WorldShip 10';
DELETE FROM configuration WHERE configuration_group_id = @tyid;
DELETE FROM configuration_group WHERE configuration_group_id = @tyid;

INSERT INTO configuration_group VALUES ('', 'Ty UPS WorldShip 10', 'Ty UPS WorldShip 10 Settings', '1', '1');
UPDATE configuration_group SET sort_order = last_insert_id() WHERE configuration_group_id = last_insert_id();
SET @tyid=7878;
SELECT (@tyid:=configuration_group_id) as tyid 
FROM configuration_group
WHERE configuration_group_title= 'Ty UPS WorldShip 10';
INSERT INTO configuration VALUES 
	('', 'UPS Account Number', 'WORLDSHIP_ACCOUNT_NUMBER', 'test', 'Enter your UPS Shipping Account number<br />Your account number is the six characters following 1Z in your tracking numbers. 1Z is not part of your account number.', @tyid, '11', now(), now(), NULL, NULL),
    ('', 'Admin Email Address', 'WORLDSHIP_EMAIL_ADDRESS', 'test@domain.com', 'Enter the admin email address that will be use for Quantum View to notify admin of shipment status', @tyid, '12', now(), now(), NULL, NULL),
    ('', 'Notify Admin Tracking Number?', 'WORLDSHIP_ADMIN_SHIP', 'False', 'If true, Quantum View will send Admin the tracking number.', @tyid, '13', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Notify Admin Delivery Exception?', 'WORLDSHIP_ADMIN_EXCEPTION', 'True', 'If true, Quantum View will send Admin an email if there is a delivery exception, delay, damage, etc...', @tyid, '14', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Notify Admin Delivery Confirmation?', 'WORLDSHIP_ADMIN_DELIVERY', 'False', 'If true, Quantum View will send Admin an email when the package was delivered.', @tyid, '15', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Notify Customer Tracking Number?', 'WORLDSHIP_CUSTOMER_SHIP', 'True', 'If true, Quantum View will send customer the tracking number on your behalf.', @tyid, '16', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Notify Customer Delivery Exception?', 'WORLDSHIP_CUSTOMER_EXCEPTION', 'True', 'If true, Quantum View will send customer an email if there is a delivery exception, delay, damage, etc...', @tyid, '17', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Notify Customer Delivery Confirmation?', 'WORLDSHIP_CUSTOMER_DELIVERY', 'False', 'If true, Quantum View will send customer an email when the package was delivered.', @tyid, '18', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Quantum View Message', 'WORLDSHIP_MESSAGE', 'Your order have been shipped.  Please contact us if you have any questions.', 'Enter a brief message to appear in Quantum View email on all emails.  Useful information would be: Stores Website URL and/or phone number.<br />(Max 150 char)', @tyid, '19', now(), now(), NULL, NULL),	 
	('', 'Comment format', 'WORLDSHIP_HTML_TEXT', 'Text', 'Are the comments in the order page display text or HTML?  By default, Zen Cart comments are display in TEXT format.', @tyid, '20', now(), now(), NULL, "zen_cfg_select_option(array('Text', 'HTML'),"),
    ('', 'Update Order Status', 'WORLDSHIP_UPDATE_STATUS', '0', 'Enter the code that you want to update the order status to after the shipping label is printed.  Enter 0 if you do not want to change the order status.  To find the status code, go to the admin/orders.php and click on the drop down menu in the status section. <br />(Example: By default, Zen Cart uses 3 as the code for DELIVERED.', @tyid, '21', now(), now(), NULL, NULL),
    ('', 'Enable Declared Value', 'WORLDSHIP_DECLARED_VALUE', 'False', 'Do you want to use the sub total price as the declared value for UPS insurance.  UPS covers each package up to $100 free of charge.  For packages that are valued over $100, UPS charges an additional $0.60 for every additional $100 worth of coverage (with a minimum charge of $1.80)', @tyid, '22', now(), now(), NULL, "zen_cfg_select_option(array('True', 'False'),"),
    ('', 'Default Address Selection Type', 'WORLDSHIP_RESIDENTIAL', 'Residential', 'If most of the packages are shipped to Residential address, select Residential.  This will mark the Residential Selection as default and shipping labels will be indentified as an Residential address so that you will be billed correctly on your UPS statements.', @tyid, '23', now(), now(), NULL, "zen_cfg_select_option(array('Residential', 'Commercial'),");