<?php
/*
////////////////////////////////////////////////////////// 
// UPS Worldship 10 - XML Auto Export Module                              //  
// By Ty Lieu (colosports)                                                                    //  
//////////////////////////////////////////////////////////  
*  Module based on:  UPS XML Auto Export .80 by Daniel Payne   
*  Released under the GNU General Public License 
*  View the file: "license.txt"

 * File ID:  ups_xml_a.php v1.0c by Ty Lieu
 */

header('Content-Type: text/xml');
header('Content-Disposition: attachment; filename="openShipment.xml"');  
require('includes/application_top.php');
include(DIR_WS_CLASSES . 'order.php');
$oID = zen_db_prepare_input($_GET["oID"]);
$order = new order($oID);  

// BOF:  Translate shipping method to UPS Service Type shipping code	
$ordermethod = $db->Execute("SELECT shipping_method FROM " . TABLE_ORDERS . " WHERE orders_id = '" . (int)$oID  . "'");

$shipping_method = array('Nxt AM', 
	'Nxt AM Ltr', 
	'Nxt', 
	'Nxt Ltr', 
	'Nxt PR', 
	'Nxt Save', 
	'Nxt Save Ltr', 
	'2nd AM', 
	'2nd AM Ltr', 
	'2nd', 
	'2nd Ltr', 
	'3 Day Select', 
	'Ground', 
	'Canada',
	'World Xp', 
	'World Xp Ltr', 
	'World Xp Plus', 
	'World Xp Plus Ltr', 
	'World Expedite');

$shipping_codes = array('1DM', 
	'1DML', 
	'1DA', 
	'1DAL', 
	'1DAPI', 
	'1DP', 
	'1DPL', 
	'2DM', 
	'2DML', 
	'2DA', 
	'2DAL', 
	'3DS', 
	'GND', 
	'STD', 
	'XPR', 
	'XPRL', 
	'XDM', 
	'XDML', 
	'XPD');

$i=0;
while(!empty($shipping_method[$i])) {
	$pos = stristr($ordermethod->fields['shipping_method'], $shipping_method[$i]);
	if (stristr($ordermethod->fields['shipping_method'], $shipping_method[$i])) {
		$shipping_method = $shipping_codes[$i];
		}	
	$i++;
	}
// EOF:  Translate shipping method to UPS Service Type shipping code	

// BOF:  Translate shipping state to abbreviated form.
$state_list = array('AL'=>"Alabama",
                'AK'=>"Alaska", 
                'AZ'=>"Arizona", 
                'AR'=>"Arkansas", 
                'CA'=>"California", 
	            'CO'=>"Colorado", 
	            'CT'=>"Connecticut", 
	            'DE'=>"Delaware", 
                'DC'=>"District of Columbia", 
                'FL'=>"Florida", 
                'GA'=>"Georgia", 
                'HI'=>"Hawaii", 
                'ID'=>"Idaho", 
                'IL'=>"Illinois", 
                'IN'=>"Indiana", 
                'IA'=>"Iowa", 
                'KS'=>"Kansas", 
                'KY'=>"Kentucky", 
                'LA'=>"Louisiana", 
                'ME'=>"Maine", 
                'MD'=>"Maryland", 
                'MA'=>"Massachusetts", 
                'MI'=>"Michigan", 
                'MN'=>"Minnesota", 
                'MS'=>"Mississippi", 
                'MO'=>"Missouri", 
                'MT'=>"Montana",
                'NE'=>"Nebraska",
                'NV'=>"Nevada",
                'NH'=>"New Hampshire",
                'NJ'=>"New Jersey",
                'NM'=>"New Mexico",
                'NY'=>"New York",
                'NC'=>"North Carolina",
                'ND'=>"North Dakota",
                'OH'=>"Ohio", 
                'OK'=>"Oklahoma", 
                'OR'=>"Oregon", 
                'PA'=>"Pennsylvania", 
                'RI'=>"Rhode Island", 
                'SC'=>"South Carolina", 
                'SD'=>"South Dakota",
                'TN'=>"Tennessee", 
                'TX'=>"Texas", 
                'UT'=>"Utah", 
                'VT'=>"Vermont", 
                'VA'=>"Virginia", 
                'WA'=>"Washington", 
                'WV'=>"West Virginia", 
                'WI'=>"Wisconsin", 
                'WY'=>"Wyoming");
				
	$delivery_state = $_GET["state"];
	foreach ($state_list as $state_abbreviation => $state_name) {		
		if ($delivery_state == $state_name)
			$delivery_state = $state_abbreviation;		
	}
// EOF:  Translate shipping state to abbreviated form.

// BOF:  Update shipping status after label is printed.	
if (WORLDSHIP_HTML_TEXT == 'HTML') 
	$comments = 'Shipping label was printed.  <a href="http://wwwapps.ups.com/WebTracking/OnlineTool?TypeOfInquiryNumber=R&SenderShipperNumber=' . WORLDSHIP_ACCOUNT_NUMBER . '&InquiryNumber=' . $oID . '" target="_blank">Click here to track.</a>';
else 	
	$comments = 'Shipping label was printed.  To track the package, go to: http://wwwapps.ups.com/WebTracking/OnlineTool?TypeOfInquiryNumber=R&SenderShipperNumber=' . WORLDSHIP_ACCOUNT_NUMBER . '&InquiryNumber=' . $oID;
	
if (WORLDSHIP_UPDATE_STATUS !== '0') {			  
	$customer_notified='1';				
    $db->Execute("update " . TABLE_ORDERS . "
                        set orders_status = '" . WORLDSHIP_UPDATE_STATUS . "', last_modified = now()
                        where orders_id = '" . (int)$oID . "'");
						
    $db->Execute("insert into " . TABLE_ORDERS_STATUS_HISTORY . "
                      (orders_id, orders_status_id, date_added, customer_notified, comments)
                      values ('" . (int)$oID . "',
                      '" . WORLDSHIP_UPDATE_STATUS . "',
                      now(),
                      '" . $customer_notified . "',
                      '" . $comments . "')");					  
}
// EOF:  Update shipping status after label is printed.		  
?>
<?php
// Begin output file for UPS WorldShip 10 XML File.
$xml_output  = '<?xml version = "1.0" encoding = "WINDOWS-1252"?>';
echo $xml_output;
?>

<OpenShipments xmlns="x-schema: OpenShipments.xdr" >
	<OpenShipment ProcessStatus="" ShipmentOption="SC" >

<ShipTo>
	<CompanyOrName><?php 
	if (!empty($_GET["company"]))
		echo ereg_replace("&", "&amp;", $_GET["company"]); 
	else
		echo ereg_replace("&", "&amp;", $_GET["name"]); 
	?></CompanyOrName>
	<Attention><?php
	if (!empty($_GET["company"]))
		echo ereg_replace("&", "&amp;", $_GET["name"]); 
	?></Attention>
	<Address1><?php echo $_GET["address"]; ?></Address1>
	<Address2><?php echo $_GET["address2"]; ?></Address2>
	<CountryTerritory><?php echo ($_GET["country"] == 'United States') ? 'US': ''; ?></CountryTerritory>
	<PostalCode><?php echo $_GET['postcode']; ?></PostalCode>
	<CityOrTown><?php echo ereg_replace("[^A-Za-z0-9 ]", "", $_GET['city']); ?></CityOrTown>
	<StateProvinceCounty><?php echo $delivery_state; ?></StateProvinceCounty>
	<Telephone><?php echo preg_replace('/\D/', '', $_GET['customer_telephone']); ?></Telephone>
	<EmailAddress><?php echo $_GET["customer_email_address"];?></EmailAddress>
	<ReceiverUpsAccountNumber><?php echo $_GET["customer_ups_account"];?></ReceiverUpsAccountNumber>
	<ResidentialIndicator><?php echo $_GET["residential_check"];?></ResidentialIndicator>
</ShipTo>

<ShipmentInformation>
	<ServiceType><?php echo $shipping_method;?></ServiceType>
	<NumberOfPackages><?php echo $_GET["nop"];?></NumberOfPackages>
	<ShipperNumber><?php echo WORLDSHIP_ACCOUNT_NUMBER;?></ShipperNumber>
	<BillingOption>PP</BillingOption>
	<BillTransportationTo><?php echo $_GET["bill_to"];?></BillTransportationTo>
</ShipmentInformation>
<?php
if ($_GET['nop'] == '') 
	$number_of_packages = '1';
else
	$number_of_packages = $_GET['nop'];
	
	for ($i=1; $i<=$number_of_packages; $i++){
	$weight = 'weight' . $i;
	$length = 'length' . $i;
	$height = 'height' . $i;
	$width = 'width' . $i;
	$declared_value = 'declared_value' . $i;
?>


<Package>
	<PackageType>CP</PackageType>
	<Weight><?php echo $_GET["$weight"];?></Weight>
	<Reference1><?php echo $_GET["oID"];?></Reference1>
	<Reference2><?php echo $_GET["reference2"];?></Reference2>
	<?php if ($_GET["$declared_value"] > '100') echo '<DeclaredValue>
		<Amount>' . ceil($_GET["$declared_value"]) . '</Amount>
	</DeclaredValue>';?>	
	<QVNOrReturnNotificationOption>
		<QVNOrReturnRecipientAndNotificationTypes><?php if ((WORLDSHIP_CUSTOMER_SHIP == 'False') && (WORLDSHIP_CUSTOMER_EXCEPTION == 'False') &&(WORLDSHIP_CUSTOMER_DELIVERY == 'False') ) echo '</QVNOrReturnRecipientAndNotificationTypes>';
else { ?>

			<EMailAddress><?php echo $_GET["customer_email_address"];?></EMailAddress>
			<Ship><?php if (WORLDSHIP_CUSTOMER_SHIP == 'False') echo '0'; else echo '1';?></Ship>
			<Exception><?php if (WORLDSHIP_CUSTOMER_EXCEPTION == 'False') echo '0'; else echo '1';?></Exception>
			<Delivery><?php if (WORLDSHIP_CUSTOMER_DELIVERY == 'False') echo '0'; else echo '1';?></Delivery>
		</QVNOrReturnRecipientAndNotificationTypes>
<?php } ?>
		<QVNOrReturnRecipientAndNotificationTypes><?php if ((WORLDSHIP_ADMIN_SHIP == 'False') && (WORLDSHIP_ADMIN_EXCEPTION == 'False') &&(WORLDSHIP_ADMIN_DELIVERY == 'False') ) echo '</QVNOrReturnRecipientAndNotificationTypes>';
else { ?>

			<EMailAddress><?php echo WORLDSHIP_EMAIL_ADDRESS;?></EMailAddress>
			<Ship><?php if (WORLDSHIP_ADMIN_SHIP == 'False') echo '0'; else echo '1';?></Ship>
			<Exception><?php if (WORLDSHIP_ADMIN_EXCEPTION == 'False') echo '0'; else echo '1';?></Exception>
			<Delivery><?php if (WORLDSHIP_ADMIN_DELIVERY == 'False') echo '0'; else echo '1';?></Delivery>
		</QVNOrReturnRecipientAndNotificationTypes>
<?php } ?>
		<ShipFromCompanyOrName><?php echo STORE_NAME;?></ShipFromCompanyOrName>
		<FailedEMailAddress><?php echo WORLDSHIP_EMAIL_ADDRESS;?></FailedEMailAddress>
		<Memo><?php echo WORLDSHIP_MESSAGE;?></Memo>
	</QVNOrReturnNotificationOption>
	<Length><?php echo $_GET["$length"];?></Length>
	<Width><?php echo $_GET["$width"];?></Width>
	<Height><?php echo $_GET["$height"];?></Height>
</Package>
<?php
}
?>
</OpenShipment>
</OpenShipments><?php // End output file for UPS WorldShip 10 XML File. ?>