<?php
/*
////////////////////////////////////////////////////////// 
// UPS Worldship 10 - XML Auto Export Module                              //  
// By Ty Lieu (colosports)                                                                    //  
//////////////////////////////////////////////////////////  
*  Module based on:  UPS XML Auto Export .80 by Daniel Payne   
*  Released under the GNU General Public License 
*  View the file: "license.txt"

 * File ID:  ups_xml_advance.php v1.0c by Ty Lieu
 */

require('includes/application_top.php');
global $db;

require(DIR_WS_CLASSES . 'order.php');
$oID = zen_db_prepare_input($_GET['oID']);
$order = new order($oID);
$action = (isset($_GET['action']) ? $_GET['action'] : 'edit');

if ($_GET['nop'] == '') 
	$number_of_packages = '1';
else
	$number_of_packages = $_GET['nop'];

if (zen_not_null($action)) {  
    $oID = zen_db_prepare_input($_GET['oID']);
    $orders_query = $db -> Execute("SELECT orders_id FROM " . TABLE_ORDERS . " WHERE orders_id = '" . (int)$oID . "'");
    $order_exists = true;
    if (!$orders_query->RecordCount()) {
      $order_exists = false;
      $messageStack->add(sprintf(ERROR_ORDER_DOES_NOT_EXIST, $oID), 'error');
    }
}

  ?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title>TY UPS WorldShip Advance Page</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
<script type="text/javascript">
  <!--
  function init()
  {
    cssjsmenu('navbar');
    if (document.getElementById)
    {
      var kill = document.getElementById('hoverJS');
      kill.disabled = true;
    }
  }
  // -->
</script>
</head>
<body onload="init()">
<!-- header //-->
<?php
  require(DIR_WS_INCLUDES . 'header.php');
?>
<!-- header_eof //-->

<!-- body //-->
<?php
  if ($order_exists == true) {
    $order = new order($oID);
    $get_info = $db->Execute("SELECT * FROM " . TABLE_ORDERS . "
                                      WHERE orders_id = '" . (int)$oID . "'");
										
?>
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>	  
    <td class="pageHeading">Ty UPS WorldShip 10 (v1.0c)</td>		
	<td align="center"><form action="http://maps.google.com/maps" method="get" target="_blank">
	Use Google Maps to check this address.<br />(Opens in new window)<input name="q" type="hidden" value="<?php echo $query; ?>">  
	<INPUT TYPE="SUBMIT" VALUE="Check Address"></form></td>	
	
	<td align="center"><form action="ups_xml_advance.php" method="get">
	Order ID: <input name="oID" size="10" value="<?php echo $oID; ?>"> 
	Number of Packages: <input name="nop" size="5" value="<?php echo $number_of_packages; ?>">  
	<INPUT TYPE="SUBMIT" VALUE="Update"></form></td>
  </tr>
</table>
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
<!-- body_text //-->
    <td width="100%" valign="top"><table border="0" width="100%" cellspacing="0" cellpadding="2">

<!-- Begin Addresses Block -->
      <tr>
      <form action="ups_xml_a.php" method="get">
      <td align="center"><table border="1" width="100%" cellspacing="3" cellpadding="3">
            <tr valign="top">
              <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
                <tr>
                  <td class="main">&nbsp;</td>
                  <td class="main"><b>SHIP TO</b></td>
                </tr>
                <tr>
                  <td class="main" align="right">Name: </td>
                  <td class="main"><input name="name" size="35" value="<?php echo $get_info->fields['delivery_name']; ?>"> * </td>
                </tr>
                <tr>
                  <td class="main" align="right">Company: </td>
                  <td class="main"><input name="company" size="35" value="<?php echo $get_info->fields['delivery_company']; ?>"></td>
                </tr>
                <tr>
                  <td class="main" align="right">Address 1: </td>
                  <td class="main"><input name="address" size="35" value="<?php echo $get_info->fields['delivery_street_address']; ?>"> * </td>
                </tr>
                <tr>
                  <td class="main" align="right">Address 2: </td>
                  <td class="main"><input name="address2" size="35" value="<?php echo $get_info->fields['delivery_suburb']; ?>"></td>
                </tr>
                <tr>
                  <td class="main" align="right">City: </td>
                  <td class="main"><input name="city" size="35" value="<?php echo $get_info->fields['delivery_city']; ?>"> * </td>
                </tr>
                <tr>
                  <td class="main" align="right">State: </td>
                  <td class="main"><input name="state" size="35" READONLY value="<?php echo $get_info->fields['delivery_state']; ?>"> * </td>
                </tr>
                <tr>
                  <td class="main" align="right">Postal Code: </td>
                  <td class="main"><input name="postcode" size="15" value="<?php echo $get_info->fields['delivery_postcode']; ?>"> * </td>
                </tr>
        
                <tr>
                  <td class="main" align="right">Country: </td>
                  <td class="main"><input name="country" size="15" value="<?php echo $get_info->fields['delivery_country']; ?>"> * </td>
                </tr>
				
	      		<tr>
	      		  <td class="main" align="right">Telephone: </td>
	      		  <td class="main"><input name='customer_telephone' size='15' value='<?php echo $get_info->fields['customers_telephone']; ?>'> * </td>
	      		</tr>
	      		<tr>
	      		  <td class="main" align="right">Email Address: </td>
	      		  <td class="main"><input name='customer_email_address' size='35' value='<?php echo $get_info->fields['customers_email_address']; ?>'> * </td>
	      		</tr>
                <tr>
                  <td class="main" align="right">Customer UPS Account: <br />(Required if BILL TO RECEIVER)</td>
                  <td class="main"><input name="customer_ups_account" size="15" value=""></td>
                </tr>
              </table></td>
			  
			  <td><table border="0" width="100%" cellspacing="0" cellpadding="2">
                <tr>
                  <td class="main">&nbsp;</td>
                  <td class="main"><b>SHIPMENT</b></td>
                </tr>
                <tr>
                  <td class="main" align="right">Shipping Method: </td>
                  <td class="main"><input name="shipping_method" size="50" value="<?php echo $get_info->fields['shipping_method']; ?>"> * </td>
                </tr>
                <tr>
				<?php if (WORLDSHIP_RESIDENTIAL == 'Residential') 
				echo '
                  <td class="main" align="center" colspan="2"><input type="radio" name="residential_check" checked="checked" value="1"> Residential Address &nbsp;&nbsp;&nbsp; <input type="radio" name="residential_check" value="0"> Commercial Address 
				  </td>';
				else
				echo '
                  <td class="main" align="center" colspan="2"><input type="radio" name="residential_check" value="1"> Residential Address &nbsp;&nbsp;&nbsp; <input type="radio" name="residential_check" checked="checked" value="0"> Commercial Address 
				  </td>';
				?>
                </tr>
                <tr>
                  <td class="main" align="right">Bill To: </td>
                  <td class="main">				  
					<select name="bill_to">
					<option value="shipper">Shipper</option>
					<option value="receiver">Receiver</option>
					</select>
				  </td>
                </tr>
                <tr>
                  <td class="main" align="right">Reference # 1: </td>
                  <td class="main"><input name="oID" size="15" READONLY value="<?php echo $oID; ?>"> * </td>
                </tr>
                <tr>
                  <td class="main" align="right">Reference # 2: </td>
                  <td class="main"><input name="reference2" size="35" value=""></td>
                </tr>
				<?php if (WORLDSHIP_DECLARED_VALUE == 'True') {
				$get_subtotal = $db -> Execute("SELECT value FROM " . TABLE_ORDERS_TOTAL . " 
							WHERE orders_id = '" . (int)$oID . "'
							AND class = 'ot_subtotal'");
				echo '
				<tr>
				  <td class="main" align="right">Subtotal for this order: </td>
                  <td class="main"><input name="subtotal" size="10" READONLY value="$'; 
				  printf('%01.2f', $get_subtotal->fields['value']);
				  echo '"></td>				
				</tr>';
				}?>
<?php
	for ($i=1; $i<=$number_of_packages; $i++){
?>
                <tr>
                  <td class="main" colspan="2" align="center"><hr /><b>PACKAGE <?php echo $i;?></b></td>
                </tr>
                <tr>
                  <td class="main" align="center" colspan="2">
                  <?php if (WORLDSHIP_DECLARED_VALUE == 'True')  echo '
				  Declared Value: $<input name="declared_value' . $i . '" size="5" value="' . ceil($get_subtotal->fields['value'] / $number_of_packages) . '">'; 
				  else echo '
                  Declared Value: <input name="declared_value<?php echo $i;?>" size="5" value="">';
				  ?>
				  L: <input name="length<?php echo $i;?>" size="1" value="">
				  W: <input name="width<?php echo $i;?>" size="1" value="">
				  H: <input name="height<?php echo $i;?>" size="1" value="">
                  Weight: <input name="weight<?php echo $i;?>" size="1" value=""> * 
				  </td>
                </tr>
<?php				
	}
?>	
				
              </table></td>
			  
            </tr>
      </table></td>
    </tr>
    </td>
  </tr>
	</table></td>
      </tr>
      	
	  
          <td align="right" valign="center">* Required Information &nbsp;&nbsp;&nbsp; <INPUT TYPE="hidden" NAME="nop" VALUE="<?php echo $number_of_packages; ?>"><INPUT TYPE="SUBMIT" VALUE="Print Label"></td>
        </tr></table></td>
      </tr>
</form>
<?php
  }
?>
    </table></td>
<!-- body_text_eof //-->
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
</body>
</html>